getwd()
setwd("C:\\Users\\it24102328\\Desktop\\Lab 4")
