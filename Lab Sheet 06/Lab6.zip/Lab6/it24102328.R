setwd("C:\\Users\\umesh\\OneDrive\\Desktop\\Lab6")
getwd()

#1
n <- 50
p <- 0.85
pbinom(46, size=n, prob=p)

lambda <- 12
dpois(15, lambda=lambda)
