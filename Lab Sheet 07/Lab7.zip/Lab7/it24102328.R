setwd("C:\\Users\\umesh\\OneDrive\\Desktop\\Lab7")
getwd()

#1
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#2
pexp(2, rate = 1/3)

#3
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)
qnorm(0.95, mean = 100, sd = 15)

