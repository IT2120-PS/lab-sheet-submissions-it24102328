setwd("C:\\Users\\umesh\\OneDrive\\Desktop\\Lab 8")
data<-read.table("Data - Lab 8.txt",header = TRUE)
fix(data)
attach(data)

##Quection 01
popmn<-mean(Nicotine)
popvar<-var(Nicotine)

##Quection 02
samples<-c()
n<-c()
for(i in 1:30){
  s<-sample(Nicotine,5,replace = TRUE )
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}

##assign column names
colnames(sample)=n
s.means<-apply(samples,2,mean)
s.varss<-apply(samples,2,var)

##Quection 03
samplemean<-mean(s.means)
samplevars<-var(s.means)

##Quection 04
popmn
samplemean

##quection 05
truevar = popvar /5                                                       
samplevars

##Exercise
setwd("C:\\Users\\umesh\\OneDrive\\Desktop\\Lab 8")

##1
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
print(weights)

##2
pop_mean <- mean(weights$Weight)
pop_sd <- sd(weights$Weight)
cat("Population Mean =", pop_mean, "\n")
cat("Population SD =", pop_sd, "\n")

##3
set.seed(123)
sample_means <- c()
sample_sds <- c()
for(i in 1:25){
  sample_data <- sample(weights$Weight, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

print(sample_means)
print(sample_sds)

#4
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("Mean of Sample Means =", mean_of_sample_means, "\n")
cat("SD of Sample Means =", sd_of_sample_means, "\n")
